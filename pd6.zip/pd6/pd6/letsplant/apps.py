from django.apps import AppConfig


class LetsplantConfig(AppConfig):
    name = 'letsplant'
